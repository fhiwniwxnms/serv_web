<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title><?= $title ?? 'Мой блог' ?></title>
    <link rel="stylesheet" href="/web_labs_tsuprun/lab7/styles.css">
</head>
<body>
<table class="layout">
    <tr>
        <td colspan="2" class="header">Мой блог</td>
    </tr>
    <tr>
        <td>